class_name Card

var house : String
var num : int
var title : String
var mesa : Label

func _init( num, house):
	self.num = num
	self.house = house
	
	self.title = ''
	if(self.num < 11):
		self.title += str(self.num)
	elif(self.num == 1):
		self.title += 'Às '
	elif(self.num == 11):
		self.title += 'Valete'
	elif(self.num == 12):
		self.title += 'Rainha'
	elif(self.num == 13):
		self.title += 'Rei'
	
	self.title += " de " + self.house

func get_value():
	if( self.num > 1 and self.num < 11):
		return self.num
	elif( self.num == 1 ):
		return 11
	elif( self.num > 10 ):
		return 10

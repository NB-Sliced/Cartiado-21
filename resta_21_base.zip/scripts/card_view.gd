extends Node2D

@onready
var num1 = get_node("num1")

func _ready():
	num1.text = '♠️'
	num1 # ♠️♥️♦️♣️
